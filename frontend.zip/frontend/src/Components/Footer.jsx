// import { assets } from '../assets/assets';

// const Footer = () => {
//   const scrollToTop = () => {
//     window.scrollTo({
//       top: 0,
//       left: 0,
//       behavior: 'smooth',
//     });
//   };

//   return (
//     <div className="f">
//       <div className="flex flex-col sm:grid grid-cols-[3fr_1fr_1fr] gap-14 my-10 mt-40 text-sm ">
//         <div className="">
//           <img src={assets.logo} alt="" className="mb-5 w-32 " />
//           <p className="w-full sm:w-2/3 text-gray-600">
//             Shop with Forever and experience the convenience of online shopping
//             like never before.
//           </p>
//         </div>

//         <div className="">
//           <p className="text-xl font-medium mb-5">COMPANY</p>

//           <ul className="flex flex-col flex-1 text-gray-600 cursor-pointer">
//             <li onClick={scrollToTop} className="mb-2">
//               Home
//             </li>
//             <li onClick={scrollToTop} className="mb-2">
//               About Us
//             </li>
//             <li onClick={scrollToTop} className="mb-2">
//               Delivery
//             </li>
//             <li onClick={scrollToTop} className="mb-2">
//               Privacy policy
//             </li>
//           </ul>
//         </div>

//         <div className="">
//           <p className="text-xl font-medium mb-5">GET IN TOUCH</p>
//           <ul className="flex flex-col flex-1 text-gray-600">
//             <li className="mb-2">+123 456 7890</li>
//             <li className="mb-2">contact@forevryou.com </li>
//           </ul>
//         </div>
//       </div>
//       <div>
//         <hr />
//         <p className="py-5 text-sm text-center">
//           Copyright 2024@ forever.com - All Rights Reserved
//         </p>
//       </div>
//     </div>
//   );
// };

// export default Footer;
import { assets } from '../assets/assets';
import logo2 from '../assets/logo2.png';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'smooth',
    });
  };

  return (
    <footer className="px-4 sm:px-10 mt-40 text-sm text-gray-600">
      {/* Main Footer Section */}
      <div className="flex flex-col sm:grid grid-cols-[3fr_1fr_1fr] gap-14 mb-10">
        {/* Logo + Description */}
        <div>
          <img src={assets.logo2} alt="TrendWave Logo" className="mb-5 w-32" />
          <p className="max-w-xs">
            Shop with <strong>TrendWave</strong> and experience the convenience of stylish clothing delivered to your doorstep.
          </p>
        </div>

        {/* Company Links */}
        <div>
          <p className="text-xl font-semibold mb-5 text-black">COMPANY</p>
          <ul className="flex flex-col gap-2 cursor-pointer">
            <li onClick={scrollToTop}>Home</li>
            <li onClick={scrollToTop}>About Us</li>
            <li onClick={scrollToTop}>Delivery</li>
            <li onClick={scrollToTop}>Privacy Policy</li>
          </ul>
        </div>

        {/* Contact Info */}
        <div>
          <p className="text-xl font-semibold mb-5 text-black">GET IN TOUCH</p>
          <ul className="flex flex-col gap-2">
            <li>+123 456 7890</li>
            <li>contact@trendwave.com</li>
          </ul>
        </div>
      </div>

      {/* Bottom Bar */}
      <hr className="border-gray-300" />
      <p className="py-5 text-center text-gray-500 text-xs">
        © 2025 TrendWave. All Rights Reserved.
      </p>
    </footer>
  );
};

export default Footer;
